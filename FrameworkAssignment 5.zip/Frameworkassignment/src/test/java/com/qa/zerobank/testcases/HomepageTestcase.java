package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;




public class HomepageTestcase extends TestBase{
	HomePage homePage;
	LogInPage logInPage;
	TestUtil testutill;
	
	public HomepageTestcase() {
		super();
	}
	
	@BeforeMethod
	public void setUp () {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
		testutill= new TestUtil();
	}
	
	@AfterMethod
	public void cleanUp () {
		// close driver
		driver.close();
		driver.quit();	
	}
	@Test
    public void validateHomePage() {
		homePage.assertHomePageTitle();
	}
	@Test
	public void signinbutton() {
		logInPage = homePage.clickOnSignInButton();
//		logInPage.assertLogInPageTitle();
}
}

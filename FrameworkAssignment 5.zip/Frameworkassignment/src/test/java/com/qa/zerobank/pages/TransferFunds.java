package com.qa.zerobank.pages;

import org.testng.annotations.Test;

public class TransferFunds {
  @Test
  public void f() {
  }
}

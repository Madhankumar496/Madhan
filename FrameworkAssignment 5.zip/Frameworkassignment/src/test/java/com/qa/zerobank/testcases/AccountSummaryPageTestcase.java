package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;

public class AccountSummaryPageTestcase extends TestBase {
	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testutill;
	String sheetName = "ZerobankNegativetestcasedata";
	
	public AccountSummaryPageTestcase() {
		super();
	}
	@BeforeMethod
	  public void beforeMethod() {
		  initialization();
			homePage = new HomePage();
			logInPage = new LogInPage();
			accountSummaryPage = new AccountSummaryPage();
			testutill=new TestUtil();
	  }
	
	
	 @AfterMethod
	  public void afterMethod() {
		  
			driver.close();
			driver.quit();
	 }
	 @Test
	 public void Accountsummarypagetestcase() {
		 homePage.clickOnSignInButton();
		 logInPage.loginvalid("username", "password");
		 accountSummaryPage.TransferFund();
		 System.out.println("logout sucess");
	 }
	 
	 
	 }
	 



package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;

import com.qa.zerobank.pages.HomePage;

import com.qa.zerobank.pages.LogInPage;

import com.qa.zerobank.util.TestUtil;



public class LogInPageTestcases extends TestBase{
	
	HomePage homePage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testutill;
	String sheetName = "ZerobankNegativetestcasedata";
	
	public LogInPageTestcases() {
		super();
	}
	@BeforeMethod
	  public void beforeMethod() {
		  initialization();
			homePage = new HomePage();
			logInPage = new LogInPage();
			accountSummaryPage = new 	AccountSummaryPage();
			testutill=new TestUtil();
	  }
	
	
	
	 @AfterMethod
	  public void afterMethod() {
		  
			driver.close();
			driver.quit();
	 }
	 	 
//	 @DataProvider
//	 public Object[][] getLoginData(){
//
//	 Object data[][]= TestUtil.getTestData("LogIn");
//	 return data;
//	 }

	 
	 
	 
//	 @Test(dataProvider = "getLoginData")
//	 public void validateLogInPageFunctionality(String username, String password) {
//	 // TODO Auto-generated method stub
//
//	 logInpage = homepage.clickOnSignInButton();
//	 driver.findElement(By.id("user_login")).sendKeys(username);
//	 driver.findElement(By.name("user_password")).sendKeys(password);
//	 driver.findElement(By.name("submit")).click();
//	 driver.findElement(By.id("details-button")).click();
//	 driver.findElement(By.id("proceed-link")).click();
//
//	 accountsummarypage.assertAccountSummaryPageTitle();
	 
		 
	 
	 @Test
	 public void loginInvalidtestcase() {
		 
	 homePage.clickOnSignInButton();
	 logInPage.loginInvalid("username123", "password");
	 logInPage.loginInvalid("username", "password123 ");
	 logInPage.loginInvalid("    ", "      ");
	 logInPage.loginInvalid(" ", "password");
	 logInPage.loginInvalid("username", " ");
	 
	 }
	 
	 

	@Test
		public void loginvalidtestcase() {
		 homePage.clickOnSignInButton();
			 logInPage.loginvalid("username", "password");
			
		}
			
			
		}
	 



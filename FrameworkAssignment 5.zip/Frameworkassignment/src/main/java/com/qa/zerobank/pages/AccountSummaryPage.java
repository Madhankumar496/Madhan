package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.zerobank.base.TestBase;



public class AccountSummaryPage extends TestBase{
	
	@FindBy(id="transfer_funds_tab")
	WebElement TransferFund;
		
	
	@FindBy(id="pay_bills_tab")
	WebElement paybill;
	

	
	@FindBy(xpath="//a[contains(text(),'Purchase Foreign Currency')]")
	WebElement purchaseforeiogncurrency;
	
	
	@FindBy(xpath="//input[@id='pc_inDollars_true']")
	WebElement radiobutton;
	
	@FindBy(id="purchase_cash")
	WebElement newlastbtn;
	
    @FindBy(xpath="//*[@id=\"settingsBox\"]/ul/li[3]/a")
    WebElement usernamebutton;
	 
	@FindBy(id="logout_link")
    WebElement logout;
    
	public AccountSummaryPage() {
        PageFactory.initElements(driver, this);
    }
	
	public void assertSummaryPageTitle() {

		assertEquals(driver.getTitle(), "Zero - Account Summary", "String Mismatch found");

	}

	
	public void TransferFund() {
		TransferFund.click();

	    paybill.click();

	    purchaseforeiogncurrency.click();
		radiobutton.click();
		 newlastbtn.click();
			
		
		WebDriverWait ewait=new WebDriverWait(driver,20);
	 	ewait.until(ExpectedConditions.alertIsPresent());
	 		    
	 		    Alert purchase =  driver.switchTo().alert();
	 		    String text =purchase.getText();
	 		    System.out.println("The text on the alert is : " + text);
	 		    purchase.accept();
	
		usernamebutton.click();
	
	}
	
	

}

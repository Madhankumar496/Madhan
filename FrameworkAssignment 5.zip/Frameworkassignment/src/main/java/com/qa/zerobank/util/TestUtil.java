package com.qa.zerobank.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.qa.zerobank.base.TestBase;



public class TestUtil extends TestBase {
	
	 
	 public static String TESTDATA_SHEET_PATH = System.getProperty("user.dir")+"\\src\\test\\resources\\com\\qa\\zerobank\\testdata\\"+prop.getProperty("testdata");
//	public static String TESTDATA_SHEET_PATH = "C:\\Trainingworkspace\\Assignment4POMDesginpattern\\"
//			+ "src\\test\\resources\\com\\qa\\zerobank\\testdata\\ZeroBankNegativeTestData.xlsx";
	
	 static Workbook book;
    static Sheet sheet;
    public static Object[][] getTestData(String sheetName){
		
		   FileInputStream file = null;

	        try {
	            file = new FileInputStream(TESTDATA_SHEET_PATH);
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        }

	        try {
	            book = WorkbookFactory.create(file);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	        sheet = book.getSheet(sheetName);
	        
	        int rowcount = sheet.getLastRowNum();
	        int columnCount = sheet.getRow(0).getLastCellNum();
       
	        Object[][] data = new Object[rowcount][columnCount];
	        
	        for (int i = 0; i < rowcount; i++) {
	            for (int k = 0; k < columnCount; k++) {
	                data[i][k] = sheet.getRow(i + 1).getCell(k).toString();
	            }
	        }
	        return data;
	        

}
}
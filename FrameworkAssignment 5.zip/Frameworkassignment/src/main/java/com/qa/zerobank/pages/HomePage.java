package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;


public class HomePage extends TestBase{
	
	@FindBy(className="Zero Bank")
	WebElement Logo;
	
	@FindBy(id="signin_button")
	WebElement signinbutton;
	
	public HomePage() {
		PageFactory.initElements(driver, this);
	}
   
	public void assertHomePageTitle(){
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Home page title assert Failed");
		
	}
	
	public void assertHomePageTitle1() {

		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Mismatch found");

	}

	
	public LogInPage clickOnSignInButton() {
		signinbutton.click();
		return new LogInPage();
}
}

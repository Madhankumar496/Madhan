package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;



public class LogInPage extends TestBase{
	@FindBy(id="user_login")
	WebElement  lusername;
	
	@FindBy(id="user_password")
	WebElement lpassword;
	
	@FindBy(name="submit")
	WebElement submitbutton;
	
	@FindBy(id="details-button")
	WebElement detailsbutton;
	
	@FindBy(linkText="Proceed to zero.webappsecurity.com (unsafe)")
	WebElement proceedtolink;
	
	public LogInPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertHomePageTitle() {

		assertEquals(driver.getTitle(), "Zero - Log in", "Mismatch found");

	}
	public void loginInvalid(String uid , String pwd) {
		lusername.sendKeys(uid);
		 lpassword.sendKeys(pwd);
		submitbutton.click();
    	//detailsbutton.click();
//		proceedtolink.click();
//		return new AccountSummarypage();
	}
	
	
	public AccountSummaryPage loginvalid(String uid , String pwd) {
		 lusername.sendKeys(uid);
		lpassword.sendKeys(pwd);
		submitbutton.click();
		detailsbutton.click();
		proceedtolink.click();
		return new AccountSummaryPage();
	}
	
	
	
	

}
